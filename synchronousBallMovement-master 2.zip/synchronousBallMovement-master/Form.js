class Form{
    constructor(){

    }

    display(){
        var title = createElement('h2')
        title.html("Car Racing Game");
        title.position(250,30)

        var input = createInput("Name");
        input.position(250,60)
        var button = createButton("Play");
        button.position(250,90)
        var greeting = createElement("h3");
        button.mousePressed(function(){
            input.hide();
            button.hide();
            var name = input.value();
            playerCount = playerCount + 1;
            player.update(name);
            player.updateCount(playerCount);
            greeting.html("Hello "+ name);
            greeting.position(250,250);
        })
        
    }
}